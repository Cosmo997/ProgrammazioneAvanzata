/**
 * <b>Responsabilit�</b>: gestire la partita, prende i codici dei giocatori e li
 * inserisce negli apposoti array
 * 
 * @author TeamTrustMe
 *
 */

public class MatchCoordinator {

}
